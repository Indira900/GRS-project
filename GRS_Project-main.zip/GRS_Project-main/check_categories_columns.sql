SHOW COLUMNS FROM categories;
